DROP SCHEMA if exists "colleges" CASCADE;
CREATE SCHEMA "colleges";
SET SCHEMA 'colleges';
CREATE TABLE _region
(
  code_region  	VARCHAR(2) PRIMARY KEY,
  libelle_region   VARCHAR(40) UNIQUE NOT NULL
);
CREATE TABLE _departement
(
  code_du_departement   INTEGER NOT NULL,
  nom_departement   	VARCHAR(30) NOT NULL,
  code_region       	VARCHAR(2) NOT NULL,
  CONSTRAINT _departement_pk PRIMARY KEY (code_du_departement),
  CONSTRAINT _departement_fk FOREIGN KEY (code_region) REFERENCES _region (code_region)
);
CREATE TABLE _commune
(
  code_insee_de_la_commune   VARCHAR(5),
  nom_de_la_commune      	VARCHAR(45) UNIQUE,
  code_du_departement    	INTEGER,
  CONSTRAINT _commune_pk PRIMARY KEY (code_insee_de_la_commune),
  CONSTRAINT _commune_fk FOREIGN KEY (code_du_departement) REFERENCES _departement (code_du_departement)
);
CREATE TABLE _academie
(
  code_academie   INTEGER NOT NULL,
  lib_academie	VARCHAR(20) NOT NULL,
  CONSTRAINT _academie_pk PRIMARY KEY (code_academie)
);
CREATE TABLE _type
(
  code_nature  	VARCHAR(5) NOT NULL,
  libelle_nature   VARCHAR(50) NOT NULL,
  CONSTRAINT _type_pk PRIMARY KEY (code_nature,libelle_nature)
);
CREATE TABLE _quartier_prioritaire
(
  code_quartier_prioritaire   VARCHAR(10),
  nom_quartier_prioritaire	VARCHAR(50),
  CONSTRAINT _quartier_prioritaire_pk PRIMARY KEY (code_quartier_prioritaire)
);
CREATE TABLE _etablissement
(
  uai                    	VARCHAR(8) NOT NULL,
  nom_etablissement      	VARCHAR(100) NOT NULL,
  secteur                	VARCHAR(10) NOT NULL,
  code_postal            	VARCHAR(5) NOT NULL,
  code_academie          	INTEGER NOT NULL,
  code_insee_de_la_commune   VARCHAR(5) NOT NULL,
  lattitude              	FLOAT NOT NULL,
  longitude              	FLOAT NOT NULL,
  CONSTRAINT _etablissement_pk PRIMARY KEY (uai),
  CONSTRAINT est_localise_dans_fk FOREIGN KEY (code_insee_de_la_commune) REFERENCES _commune (code_insee_de_la_commune),
  CONSTRAINT depend_de_fk FOREIGN KEY (code_academie) REFERENCES _academie (code_academie)
);
CREATE TABLE _est_a_proximite_de
(
  code_quartier_prioritaire   VARCHAR(10),
  uai                     	VARCHAR(8),
  CONSTRAINT est_a_proximite_de_pk PRIMARY KEY (uai),
  CONSTRAINT est_a_proximite_de_fk1 FOREIGN KEY (code_quartier_prioritaire) REFERENCES _quartier_prioritaire (code_quartier_prioritaire),
  CONSTRAINT est_a_proximite_de_fk2 FOREIGN KEY (uai) REFERENCES _etablissement (uai)
);
CREATE TABLE _annee
(
  annee_scolaire   VARCHAR(9),
  CONSTRAINT _annee_pk PRIMARY KEY (annee_scolaire)
);
CREATE TABLE _classe
(
  id_classe   VARCHAR(5),
  CONSTRAINT _classe_pk PRIMARY KEY (id_classe)
);
CREATE TABLE _caracteristiques_tout_etablissement
(
  uai               	VARCHAR(8),
  annee_scolaire    	VARCHAR(10),
  effectif          	INTEGER,
  ips               	FLOAT,
  ecart_type_de_l_ips   FLOAT,
  ep                	VARCHAR(7),
  CONSTRAINT caracteristiques_tout_etablissement_pk PRIMARY KEY (uai,annee_scolaire),
  CONSTRAINT caracteristiques_tout_etablissement_fk1 FOREIGN KEY (uai) REFERENCES _etablissement (uai),
  CONSTRAINT caracteristiques_tout_etablissement_fk2 FOREIGN KEY (annee_scolaire) REFERENCES _annee (annee_scolaire)
);
CREATE TABLE _caracteristique_college
(
  nbre_eleves_hors_segpa_hors_ulis   INTEGER,
  nbre_eleves_segpa              	INTEGER,
  nbre_eleves_ulis               	INTEGER,
  uai                            	VARCHAR(8),
  annee_scolaire                 	VARCHAR(10),
  CONSTRAINT caracteristiques_college_pk PRIMARY KEY (uai,annee_scolaire),
  CONSTRAINT caracteristiques_college_fk1 FOREIGN KEY (uai) REFERENCES _etablissement (uai),
  CONSTRAINT caracteristiques_college_fk2 FOREIGN KEY (annee_scolaire) REFERENCES _annee (annee_scolaire)
);
CREATE TABLE _caracteristiques_selon_classe
(
  nbre_eleves_hors_segpa_hors_ulis_selon_niveau   INTEGER,
  nbre_eleves_segpa_selon_niveau              	INTEGER,
  nbre_eleves_ulis_selon_niveau               	INTEGER,
  effectif_filles                             	INTEGER,
  effectif_garcons                            	INTEGER,
  uai                                         	VARCHAR(8),
  annee_scolaire                              	VARCHAR(10),
  id_classe                                   	VARCHAR(5),
  CONSTRAINT caracteristiques_selon_classe_pk PRIMARY KEY (uai,annee_scolaire),
  CONSTRAINT caracteristiques_selon_classe_fk1 FOREIGN KEY (uai) REFERENCES _etablissement (uai),
  CONSTRAINT caracteristiques_selon_classe_fk2 FOREIGN KEY (annee_scolaire) REFERENCES _annee (annee_scolaire),
  CONSTRAINT caracteristiques_selon_classe_fk3 FOREIGN KEY (id_classe) REFERENCES _classe (id_classe)
);



