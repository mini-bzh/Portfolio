import numpy as np
import matplotlib.pyplot as plt
import donnees
import matrice_covariance

def DiagBatons(Colonne:np.ndarray)->None:
    m= min(Colonne)
    M= max(Colonne)
    r= 21

    inter=[m+i*(M-m)/r for i in range(r)]
    plt.hist(Colonne, inter, histtype='bar', align='left', rwidth=0.3)
    plt.show()
    
    
def DiagMoustache(dataAR:np.ndarray, nomLi:list)->None:
    plt.boxplot(dataAR,labels=nomLi)
    plt.show()
    
def intervales_quartiles(dataAR:np.ndarray)->(np.ndarray,np.ndarray,np.ndarray,np.ndarray):
    Q0 = np.percentile(dataAR, 0)
    Q1 = np.percentile(dataAR, 25)
    Q2 = np.percentile(dataAR, 50)
    Q3 = np.percentile(dataAR, 75)
    Q4 = np.percentile(dataAR, 100)
    
    IQR = Q3 - Q1
    
    seuil_bas = Q1 - 1.5 * IQR
    seuil_haut = Q3 + 1.5 * IQR
    
    intervale_Q0_Q1_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x > Q0 and x < Q1 and x > seuil_bas])
    intervale_Q1_Q2_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x > Q1 and x < Q2])
    intervale_Q2_Q3_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x > Q2 and x < Q3])
    intervale_Q3_Q4_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x > Q3 and x < Q4 and x < seuil_haut])
    
    
    return intervale_Q0_Q1_AR ,intervale_Q1_Q2_AR ,intervale_Q2_Q3_AR ,intervale_Q3_Q4_AR

def valeurs_aberrantes(dataAR:np.ndarray)->(np.ndarray,np.ndarray):
    Q1 = np.percentile(dataAR, 25)
    Q3 = np.percentile(dataAR, 75)
    IQR = Q3 - Q1
    
    seuil_bas = Q1 - 1.5 * IQR
    seuil_haut = Q3 + 1.5 * IQR
    
    valeurs_aberrantes_haut_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x > seuil_haut])
    valeurs_aberrantes_bas_AR = np.array([i[0] for i,x in np.ndenumerate(dataAR) if x < seuil_bas])
    
    return valeurs_aberrantes_haut_AR, valeurs_aberrantes_bas_AR

def moyenne(AR:np.ndarray)->float:
    return sum(AR.tolist())*1.0/AR.shape[0]

def variance(AR:np.ndarray)->float:
    return moyenne(AR*AR) - moyenne(AR)**2

if __name__ == '__main__':
    
    print("\n -> taux_de_reussite_g pour comparer")
    print(f" moyenne : {moyenne(donnees.transformAR[4]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4]):.2f}")
    
    print("\n -> valeurs_aberrantes hautes de nom_de_l_etablissement")
    print(f" moyenne : {moyenne(donnees.transformAR[4,valeurs_aberrantes(donnees.transformAR[0])[0]]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4,valeurs_aberrantes(donnees.transformAR[0])[0]]):.2f}")
        # On prend ici les valeurs aberrantes hautes de nom_de_l_etablissement
        # On voit une variance éloignée de 1 ce qui indique des résultats différents au taux_de_reussite_g
        # On a une moyenne supérieur à celle de taux_de_reussite_g

    print("\n -> entre q0 et q1 de nom_de_l_etablissement")
    print(f" moyenne : {moyenne(donnees.transformAR[4,intervales_quartiles(donnees.transformAR[0])[0]]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4,intervales_quartiles(donnees.transformAR[0])[0]]):.2f}")
        # On prend ici les valeurs entre q0 et q1 de nom_de_l_etablissement
        # On voit une variance proche de 1 ce qui indique des résultats similaires au taux_de_reussite_g
        # On a une moyenne légèrement inférieur à celle de taux_de_reussite_g


    print("\n -> entre q3 et q4 de commune")
    print(f" moyenne : {moyenne(donnees.transformAR[4,intervales_quartiles(donnees.transformAR[1])[3]]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4,intervales_quartiles(donnees.transformAR[1])[3]]):.2f}")
        # On prend ici les valeurs entre q3 et q4 de commune
        # On voit une variance proche de 1 ce qui indique des résultats similaires au taux_de_reussite_g
        # On a une moyenne très légèrement supérieur à celle de taux_de_reussite_g
        
        
    print("\n -> entre q3 et q4 de departement")
    print(f" moyenne : {moyenne(donnees.transformAR[4,intervales_quartiles(donnees.transformAR[2])[0]]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4,intervales_quartiles(donnees.transformAR[2])[0]]):.2f}")
        # On prend ici les valeurs entre q3 et q4 de commune
        # On voit une variance proche de 1 ce qui indique des résultats similaires au taux_de_reussite_g
        # On a une moyenne très légèrement inférieur à celle de taux_de_reussite_g
        
    print("\n -> entre q3 et q4 de academie")
    print(f" moyenne : {moyenne(donnees.transformAR[4,intervales_quartiles(donnees.transformAR[3])[3]]):.2f}")
    print(f" variance : {variance(donnees.centrerduitAR[4,intervales_quartiles(donnees.transformAR[3])[3]]):.2f}")
        # On prend ici les valeurs entre q3 et q4 de academie
        # On observe une variance et une moyenne similaire à celles de taux_de_reussite_g
    
    
### BONUS
    if str(input("Bonus (o/n) : ")) == "o":
        
        #DiagMoustache(donnees.transformAR.transpose(),donnees.importDF.columns)

 
        print(" -> Matrice de covariance entre q3 et q4 de academie")
        cov = np.cov(donnees.centreduire(donnees.transformAR[:,intervales_quartiles(donnees.transformAR[3])[3]]).transpose(),rowvar=False)
        matrice_covariance.aff_mat_cov(cov)
        # On prend ici les valeurs entre q3 et q4 de academie
        # On observe une correlation plus elevé avec taux_de_reussite_g
        # Elle reste toujours faibre cela dit


