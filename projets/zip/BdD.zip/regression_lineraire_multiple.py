import numpy as np
import numpy.linalg as la
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import donnees

X_AR = donnees.centrerduitAR[:4].transpose()
Y_AR = donnees.centrerduitAR[4].transpose()

#print(X_AR)
#print(np.ones((X.shape[0], 1)))

X1_AR = np.concatenate((np.ones((X_AR.shape[0], 1)), X_AR), axis=1)

#print(X1_AR)

a_AR = (la.inv(X1_AR.transpose()@X1_AR)@X1_AR.transpose()@Y_AR)[1:]

#linear_regression = LinearRegression()
#linear_regression.fit(X_AR, Y_AR)
#a=linear_regression.coef_

print(a_AR)

Ypred_AR = np.array([sum(i_AR*a_AR) for i_AR in X_AR])
#print(Ypred_AR)

CorM = (1 - sum((Ypred_AR-Y_AR)**2) / (len(Ypred_AR)*np.var(Y_AR))) ** (1/2)
print(f"Coefficient de corrélation multiple : {CorM:.4f}")

#La correlation est faible
