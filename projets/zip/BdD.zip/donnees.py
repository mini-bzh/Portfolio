import pandas as pd
import numpy as np

def centreduire(AR:np.ndarray):
    resultAR = np.zeros(AR.shape)
    
    for i in range(AR.shape[0]):
        avg = np.average(AR[i])
        ecty = np.std(AR[i])
        
        resultAR[i,:]=(AR[i,:]-avg)/ecty

    return resultAR

### Importation des donnees
try:
    importDF = pd.read_csv("etablissements.csv", delimiter = ";")
    importDF.dropna()
    print("###   IMPORTATION   OK ###\n\n")
except Exception:
    raise Exception("Erreur pendant l'importation du fichier")

### Verification des colonnes
if True in [v not in importDF.columns for v in ['nom_de_l_etablissement', 'commune', 'departement', 'academie','taux_de_reussite_g']]:
    raise Exception("Erreur sur les colonnes du fichier csv")
else:
    print("###    COLONNES     OK ###\n\n")


### Transformation des donnees
importAR = importDF.to_numpy()
transformAR = np.zeros(importAR.shape)


for pos, val in np.ndenumerate(importAR):	## nom de lieux -> leur longueur
    if pos[1] == 4: 						#
        transformAR[pos] = val				## la serie 4 est déjà numérique
    else:									#
        transformAR[pos] = len(val)			#

transformAR = transformAR.transpose()

print("###  TRANSFORMATION OK ###\n\n")

###Centre reduire
centrerduitAR = centreduire(transformAR)

print("###  CENTRE REDUIRE OK ###\n\n")
