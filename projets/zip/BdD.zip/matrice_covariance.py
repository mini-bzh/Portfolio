import numpy as np
import matplotlib.pyplot as plt
import donnees

def aff_mat_cov(cov:np.ndarray):
    
    plt.figure(figsize=cov.shape)
    plt.matshow(cov, fignum=1)
    
    plt.colorbar()
    plt.title('Matrice de Covariance')
    plt.xticks(range(cov.shape[0]), donnees.importDF.columns)
    plt.yticks(range(cov.shape[0]), donnees.importDF.columns)

    # Affichage des valeurs
    for (i, j), val in np.ndenumerate(cov):
        plt.text(j, i, f'{val:.2f}', ha='center', va='center', color='white')

    plt.show()

cov = np.cov(donnees.centrerduitAR.transpose(),rowvar=False) #calcul de la matrice de covariance

if __name__ == '__main__':
    aff_mat_cov(cov)