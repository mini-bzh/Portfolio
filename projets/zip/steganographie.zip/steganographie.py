import PIL.Image
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from random import randint



def bruit(tab):
    """
    cree un bruit dans le tableau tab
    """
    result = tab
    for i in range(len(tab)):
        for j in range(len(tab[0])):
            for e in range(3):
                result[i][j][e] = int(bin(result[i][j][e])[2:-1]+str(randint(0,1)),2)
    return result


def steganographie(tab,mess,saut=0):
    """
    cache un message a partir de "saut" dans le tableau en separant chaque caractere entre le Rouge et le Vert sur 4 pixels
    en modifiant le dernier bit des valeur et entre chaque caractere cacher dans le tableau ce trouve un saut qui se fait
    avec "ant" en fonction du code ascii du caractere antecedant

    """
    if saut + len(mess)*4 > len(tab)*len(tab[0]):
        return None
    ant = 0                                                         # initialisation de la variable de saut entre les charactere
    tab[(saut)//len(tab[0])][(saut)%(len(tab[0]))][2] = len(mess)   # sauvgarde de la longueur du message dans la couleur Bleu
    for i in range(saut,len(mess)*4+saut,4):
        binary = bin(ord(mess[(i-saut)//4]))[2:]                     # mise en binaire d un caractere
        while len(binary)!=8:                                       # mise du binaire en str de 8 caractere
            binary = '0' + binary
        for e in range(4):                                          # modification des donnees du tableau pour incorporer ->
                                                                    # les donnees du binaire en les separents dans le Rouge->
                                                                    # et le Vert sur 4 pixels
            t1 = bin(tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][0])[2:]
            t2 = bin(tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][1])[2:]
            t1 = '0'*(8-len(t1))+t1[:-1]
            t2 = '0'*(8-len(t2))+t2[:-1]
            tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][0] = int('0b' + t1 + binary[e*2],2)
            tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][1] = int('0b' + t2 + binary[e*2+1],2)
        ant += ord(mess[(i-saut)//4])                                # modification du saut en rajoutant le code ascii du ->
                                                                    # caractere antecedant
    return tab

def dechiffreur(tab,saut):
    """
    trouve la longeur du message a partir de "saut" puis recupere les valeur du message avec 4 pixels dans leur valeurs Rouge et
    Verte dans leur dernier bit puis reconstitu le message a partir de ca
    """
    longeurmess = tab[(saut)//len(tab[0])][(saut)%(len(tab[0]))][2]
    ant = 0
    result = ""
    for i in range(saut,longeurmess*4+saut,4):
        binary = ""
        for e in range(4):
            binary += str(bin(tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][0])[-1]) + str(bin(tab[(i+e+ant)//len(tab[0])][(i+e+ant)%(len(tab[0]))][1])[-1])
        result += chr(int('0b'+binary,2))
        ant += ord(result[(i-saut)//4])
    return result

image = Image.open("image_ref.jpg")

T = np.array(image)

mess = "FLAG : STEGOZOR"
cle = 100000

final = steganographie(bruit(T),mess,cle)
#Programme tres lent a cause du bruit

imagefinal = PIL.Image.fromarray(final)
T2 = np.array(imagefinal)
print(dechiffreur(T2,cle))
imagefinal.show()
imagefinal.save("image_final.jpg")

